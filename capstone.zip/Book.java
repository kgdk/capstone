public class Book {
	private int id;
	private String title;
    private String author;
    private String genre;
    private boolean isCheckIn;
    private static int nextId=0;

	public Book(String title, String author, String genre) {
		this.id = nextId;
		this.title = title.toUpperCase();
		this.author = author.toUpperCase();
		this.genre = genre.toUpperCase();
		isCheckIn = true;
		nextId++;
	}
	
	public int getId() {
		return id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}
	
    public String getGenre(){
        return genre ;
    }
    
    public void setGenre(String genre){
        this.genre = genre;
    }
    
    public boolean getCheckIn() {
    	return isCheckIn;
    }
    public void setCheckOut() {
    	isCheckIn = false;
    }
    public void setCheckIn() {
    	isCheckIn = true;
    }
	
	public String toString(){
		return String.format("%-50s%-30s%-20s%-15s%-10s%n", title, author, genre, isCheckIn,id);
	}

}
